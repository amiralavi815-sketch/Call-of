package com.codcommandcenter.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFE53935)
private val Muted = Color(0xFFBDBDBD)

private val Nicknames = listOf(
    "IronVex",
    "IronByte",
    "IronStrike",
    "IronHawk",
    "IronFang",
    "IronCore",
    "IronFlux",
    "IronReign",
    "IronClaw",
    "IronNexus",
    "IronRift",
    "IronVolt",
    "IronEdge",
    "IronShade",
    "IronLock",
    "IronDash",
    "IronForge",
    "IronX",
    "IronOps",
    "IronPrime",
    "GhostVex",
    "GhostByte",
    "GhostStrike",
    "GhostHawk",
    "GhostFang",
    "GhostCore",
    "GhostFlux",
    "GhostReign",
    "GhostClaw",
    "GhostNexus",
    "GhostRift",
    "GhostVolt",
    "GhostEdge",
    "GhostShade",
    "GhostLock",
    "GhostDash",
    "GhostForge",
    "GhostX",
    "GhostOps",
    "GhostPrime",
    "ShadowVex",
    "ShadowByte",
    "ShadowStrike",
    "ShadowHawk",
    "ShadowFang",
    "ShadowCore",
    "ShadowFlux",
    "ShadowReign",
    "ShadowClaw",
    "ShadowNexus",
    "ShadowRift",
    "ShadowVolt",
    "ShadowEdge",
    "ShadowShade",
    "ShadowLock",
    "ShadowDash",
    "ShadowForge",
    "ShadowX",
    "ShadowOps",
    "ShadowPrime",
    "RogueVex",
    "RogueByte",
    "RogueStrike",
    "RogueHawk",
    "RogueFang",
    "RogueCore",
    "RogueFlux",
    "RogueReign",
    "RogueClaw",
    "RogueNexus",
    "RogueRift",
    "RogueVolt",
    "RogueEdge",
    "RogueShade",
    "RogueLock",
    "RogueDash",
    "RogueForge",
    "RogueX",
    "RogueOps",
    "RoguePrime",
    "ViperVex",
    "ViperByte",
    "ViperStrike",
    "ViperHawk",
    "ViperFang",
    "ViperCore",
    "ViperFlux",
    "ViperReign",
    "ViperClaw",
    "ViperNexus",
    "ViperRift",
    "ViperVolt",
    "ViperEdge",
    "ViperShade",
    "ViperLock",
    "ViperDash",
    "ViperForge",
    "ViperX",
    "ViperOps",
    "ViperPrime",
    "NovaVex",
    "NovaByte",
    "NovaStrike",
    "NovaHawk",
    "NovaFang",
    "NovaCore",
    "NovaFlux",
    "NovaReign",
    "NovaClaw",
    "NovaNexus",
    "NovaRift",
    "NovaVolt",
    "NovaEdge",
    "NovaShade",
    "NovaLock",
    "NovaDash",
    "NovaForge",
    "NovaX",
    "NovaOps",
    "NovaPrime",
    "FrostVex",
    "FrostByte",
    "FrostStrike",
    "FrostHawk",
    "FrostFang",
    "FrostCore",
    "FrostFlux",
    "FrostReign",
    "FrostClaw",
    "FrostNexus",
    "FrostRift",
    "FrostVolt",
    "FrostEdge",
    "FrostShade",
    "FrostLock",
    "FrostDash",
    "FrostForge",
    "FrostX",
    "FrostOps",
    "FrostPrime",
    "StormVex",
    "StormByte",
    "StormStrike",
    "StormHawk",
    "StormFang",
    "StormCore",
    "StormFlux",
    "StormReign",
    "StormClaw",
    "StormNexus",
    "StormRift",
    "StormVolt",
    "StormEdge",
    "StormShade",
    "StormLock",
    "StormDash",
    "StormForge",
    "StormX",
    "StormOps",
    "StormPrime",
    "RavenVex",
    "RavenByte",
    "RavenStrike",
    "RavenHawk",
    "RavenFang",
    "RavenCore",
    "RavenFlux",
    "RavenReign",
    "RavenClaw",
    "RavenNexus",
    "RavenRift",
    "RavenVolt",
    "RavenEdge",
    "RavenShade",
    "RavenLock",
    "RavenDash",
    "RavenForge",
    "RavenX",
    "RavenOps",
    "RavenPrime",
    "CobraVex",
    "CobraByte",
    "CobraStrike",
    "CobraHawk",
    "CobraFang",
    "CobraCore",
    "CobraFlux",
    "CobraReign",
    "CobraClaw",
    "CobraNexus",
    "CobraRift",
    "CobraVolt",
    "CobraEdge",
    "CobraShade",
    "CobraLock",
    "CobraDash",
    "CobraForge",
    "CobraX",
    "CobraOps",
    "CobraPrime",
    "PhantomVex",
    "PhantomByte",
    "PhantomStrike",
    "PhantomHawk",
    "PhantomFang",
    "PhantomCore",
    "PhantomFlux",
    "PhantomReign",
    "PhantomClaw",
    "PhantomNexus",
    "PhantomRift",
    "PhantomVolt",
    "PhantomEdge",
    "PhantomShade",
    "PhantomLock",
    "PhantomDash",
    "PhantomForge",
    "PhantomX",
    "PhantomOps",
    "PhantomPrime",
    "CyberVex",
    "CyberByte",
    "CyberStrike",
    "CyberHawk",
    "CyberFang",
    "CyberCore",
    "CyberFlux",
    "CyberReign",
    "CyberClaw",
    "CyberNexus",
    "CyberRift",
    "CyberVolt",
    "CyberEdge",
    "CyberShade",
    "CyberLock",
    "CyberDash",
    "CyberForge",
    "CyberX",
    "CyberOps",
    "CyberPrime",
    "SteelVex",
    "SteelByte",
    "SteelStrike",
    "SteelHawk",
    "SteelFang",
    "SteelCore",
    "SteelFlux",
    "SteelReign",
    "SteelClaw",
    "SteelNexus",
    "SteelRift",
    "SteelVolt",
    "SteelEdge",
    "SteelShade",
    "SteelLock",
    "SteelDash",
    "SteelForge",
    "SteelX",
    "SteelOps",
    "SteelPrime",
    "NightVex",
    "NightByte",
    "NightStrike",
    "NightHawk",
    "NightFang",
    "NightCore",
    "NightFlux",
    "NightReign",
    "NightClaw",
    "NightNexus",
    "NightRift",
    "NightVolt",
    "NightEdge",
    "NightShade",
    "NightLock",
    "NightDash",
    "NightForge",
    "NightX",
    "NightOps",
    "NightPrime",
    "BlazeVex",
    "BlazeByte",
    "BlazeStrike",
    "BlazeHawk",
    "BlazeFang",
    "BlazeCore",
    "BlazeFlux",
    "BlazeReign",
    "BlazeClaw",
    "BlazeNexus",
    "BlazeRift",
    "BlazeVolt",
    "BlazeEdge",
    "BlazeShade",
    "BlazeLock",
    "BlazeDash",
    "BlazeForge",
    "BlazeX",
    "BlazeOps",
    "BlazePrime",
    "VenomVex",
    "VenomByte",
    "VenomStrike",
    "VenomHawk",
    "VenomFang",
    "VenomCore",
    "VenomFlux",
    "VenomReign",
    "VenomClaw",
    "VenomNexus",
    "VenomRift",
    "VenomVolt",
    "VenomEdge",
    "VenomShade",
    "VenomLock",
    "VenomDash",
    "VenomForge",
    "VenomX",
    "VenomOps",
    "VenomPrime",
    "EchoVex",
    "EchoByte",
    "EchoStrike",
    "EchoHawk",
    "EchoFang",
    "EchoCore",
    "EchoFlux",
    "EchoReign",
    "EchoClaw",
    "EchoNexus",
    "EchoRift",
    "EchoVolt",
    "EchoEdge",
    "EchoShade",
    "EchoLock",
    "EchoDash",
    "EchoForge",
    "EchoX",
    "EchoOps",
    "EchoPrime",
    "ZeroVex",
    "ZeroByte",
    "ZeroStrike",
    "ZeroHawk",
    "ZeroFang",
    "ZeroCore",
    "ZeroFlux",
    "ZeroReign",
    "ZeroClaw",
    "ZeroNexus",
    "ZeroRift",
    "ZeroVolt",
    "ZeroEdge",
    "ZeroShade",
    "ZeroLock",
    "ZeroDash",
    "ZeroForge",
    "ZeroX",
    "ZeroOps",
    "ZeroPrime",
    "TitanVex",
    "TitanByte",
    "TitanStrike",
    "TitanHawk",
    "TitanFang",
    "TitanCore",
    "TitanFlux",
    "TitanReign",
    "TitanClaw",
    "TitanNexus",
    "TitanRift",
    "TitanVolt",
    "TitanEdge",
    "TitanShade",
    "TitanLock",
    "TitanDash",
    "TitanForge",
    "TitanX",
    "TitanOps",
    "TitanPrime",
    "WolfVex",
    "WolfByte",
    "WolfStrike",
    "WolfHawk",
    "WolfFang",
    "WolfCore",
    "WolfFlux",
    "WolfReign",
    "WolfClaw",
    "WolfNexus",
    "WolfRift",
    "WolfVolt",
    "WolfEdge",
    "WolfShade",
    "WolfLock",
    "WolfDash",
    "WolfForge",
    "WolfX",
    "WolfOps",
    "WolfPrime",
    "OnyxVex",
    "OnyxByte",
    "OnyxStrike",
    "OnyxHawk",
    "OnyxFang",
    "OnyxCore",
    "OnyxFlux",
    "OnyxReign",
    "OnyxClaw",
    "OnyxNexus",
    "OnyxRift",
    "OnyxVolt",
    "OnyxEdge",
    "OnyxShade",
    "OnyxLock",
    "OnyxDash",
    "OnyxForge",
    "OnyxX",
    "OnyxOps",
    "OnyxPrime",
    "PulseVex",
    "PulseByte",
    "PulseStrike",
    "PulseHawk",
    "PulseFang",
    "PulseCore",
    "PulseFlux",
    "PulseReign",
    "PulseClaw",
    "PulseNexus",
    "PulseRift",
    "PulseVolt",
    "PulseEdge",
    "PulseShade",
    "PulseLock",
    "PulseDash",
    "PulseForge",
    "PulseX",
    "PulseOps",
    "PulsePrime",
    "ApexVex",
    "ApexByte",
    "ApexStrike",
    "ApexHawk",
    "ApexFang",
    "ApexCore",
    "ApexFlux",
    "ApexReign",
    "ApexClaw",
    "ApexNexus",
    "ApexRift",
    "ApexVolt",
    "ApexEdge",
    "ApexShade",
    "ApexLock",
    "ApexDash",
    "ApexForge",
    "ApexX",
    "ApexOps",
    "ApexPrime",
    "DriftVex",
    "DriftByte",
    "DriftStrike",
    "DriftHawk",
    "DriftFang",
    "DriftCore",
    "DriftFlux",
    "DriftReign",
    "DriftClaw",
    "DriftNexus",
    "DriftRift",
    "DriftVolt",
    "DriftEdge",
    "DriftShade",
    "DriftLock",
    "DriftDash",
    "DriftForge",
    "DriftX",
    "DriftOps",
    "DriftPrime",
    "HexVex",
    "HexByte",
    "HexStrike",
    "HexHawk",
    "HexFang",
    "HexCore",
    "HexFlux",
    "HexReign",
    "HexClaw",
    "HexNexus",
    "HexRift",
    "HexVolt",
    "HexEdge",
    "HexShade",
    "HexLock",
    "HexDash",
    "HexForge",
    "HexX",
    "HexOps",
    "HexPrime"
)


data class GameAccount(val id: Long, val title: String, val region: String, val tokens: Int, val note: String)
data class TaskItem(val id: Long, val accountId: Long, val title: String, val done: Boolean)

class MainActivity : ComponentActivity() {
    private val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { CommandCenter(this) }
    }
}

class HourlyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("cod_cc", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("hourly_enabled", false)
        if (enabled) {
            val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(android.app.NotificationChannel("cod_reminders", "COD reminders", android.app.NotificationManager.IMPORTANCE_DEFAULT))
            }
            val builder = if (Build.VERSION.SDK_INT >= 26)
                android.app.Notification.Builder(applicationContext, "cod_reminders")
            else android.app.Notification.Builder(applicationContext)
            val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("COD COMMAND CENTER")
                .setContentText("زمان بررسی مأموریت‌ها، توکن‌ها و جوایز حساب‌هاست.")
                .setAutoCancel(true).build()
            nm.notify(1001, notification)
        }
        return Result.success()
    }
}

@Composable
fun CommandCenter(context: Context) {
    val prefs = remember { context.getSharedPreferences("cod_cc", Context.MODE_PRIVATE) }
    var accounts by remember { mutableStateOf(loadAccounts(prefs)) }
    var tasks by remember { mutableStateOf(loadTasks(prefs)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var nicknameQuery by remember { mutableStateOf("") }
    var chosenNickname by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var alias by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("Global") }
    var tokens by remember { mutableStateOf("0") }
    var note by remember { mutableStateOf("") }
    var taskTitle by remember { mutableStateOf("") }
    var taskAccount by remember { mutableStateOf<Long?>(null) }
    var hourly by remember { mutableStateOf(prefs.getBoolean("hourly_enabled", false)) }
    var operationChecks by remember { mutableStateOf(loadOperationChecks(prefs)) }

    fun saveAll() {
        prefs.edit().putString("accounts", JSONArray().apply {
            accounts.forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("region", it.region).put("tokens", it.tokens).put("note", it.note)) }
        }.toString()).putString("tasks", JSONArray().apply {
            tasks.forEach { put(JSONObject().put("id", it.id).put("accountId", it.accountId).put("title", it.title).put("done", it.done)) }
        }.toString()).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, topBar = {
            Column(Modifier.fillMaxWidth().background(Bg).padding(18.dp)) {
                Text("COD COMMAND CENTER", color = Red, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text("MULTI-ACCOUNT CONTROL PANEL", color = Muted, style = MaterialTheme.typography.labelSmall)
            }
        }, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Text("▣") }, label = { Text("حساب‌ها") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Text("✓") }, label = { Text("مأموریت‌ها") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Notifications, null) }, label = { Text("گزارش") })
                NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3 }, icon = { Text("✦") }, label = { Text("اسم‌ها") })
                NavigationBarItem(selected = selectedTab == 4, onClick = { selectedTab = 4 }, icon = { Text("➜") }, label = { Text("مراحل") })
            }
        }, floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Red, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "افزودن")
            }
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("حساب‌ها", accounts.size.toString(), Modifier.weight(1f))
                    StatCard("مجموع توکن ثبت‌شده", accounts.sumOf { it.tokens }.toString(), Modifier.weight(1f))
                    StatCard("مأموریت باز", tasks.count { !it.done }.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                when (selectedTab) {
                    0 -> {
                        Text("حساب‌های ثبت‌شده", color = Color.White, fontWeight = FontWeight.Bold)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
                            items(accounts, key = { it.id }) { a ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(a.title, color = Color.White, fontWeight = FontWeight.Bold)
                                                Text("منطقه: ${a.region}  •  توکن: ${a.tokens}", color = Muted)
                                            }
                                            IconButton(onClick = {
                                                accounts = accounts.filterNot { it.id == a.id }
                                                tasks = tasks.filterNot { it.accountId == a.id }; saveAll()
                                            }) { Icon(Icons.Default.Delete, null, tint = Red) }
                                        }
                                        if (a.note.isNotBlank()) Text(a.note, color = Muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            if (accounts.isEmpty()) item { EmptyHint("هنوز حسابی ثبت نشده؛ دکمه + را بزن.") }
                        }
                    }
                    1 -> {
                        Text("چک‌لیست دستی مأموریت‌ها", color = Color.White, fontWeight = FontWeight.Bold)
                        OutlinedTextField(taskTitle, { taskTitle = it }, label = { Text("عنوان مأموریت") }, modifier = Modifier.fillMaxWidth())
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                            OutlinedTextField(
                                value = accounts.firstOrNull { it.id == taskAccount }?.title ?: "انتخاب حساب",
                                onValueChange = {}, readOnly = true, label = { Text("حساب") },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                accounts.forEach { a -> DropdownMenuItem(text = { Text(a.title) }, onClick = { taskAccount = a.id; expanded = false }) }
                            }
                        }
                        Button(onClick = {
                            val acc = taskAccount
                            if (taskTitle.isNotBlank() && acc != null) {
                                tasks = tasks + TaskItem(System.currentTimeMillis(), acc, taskTitle.trim(), false)
                                taskTitle = ""; saveAll()
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("افزودن مأموریت") }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(tasks, key = { it.id }) { t ->
                                val accName = accounts.firstOrNull { it.id == t.accountId }?.title ?: "حساب حذف‌شده"
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = t.done, onCheckedChange = { v ->
                                            tasks = tasks.map { if (it.id == t.id) it.copy(done = v) else it }; saveAll()
                                        })
                                        Column(Modifier.weight(1f)) {
                                            Text(t.title, color = Color.White)
                                            Text(accName, color = Muted, style = MaterialTheme.typography.labelSmall)
                                        }
                                        IconButton(onClick = { tasks = tasks.filterNot { it.id == t.id }; saveAll() }) {
                                            Icon(Icons.Default.Delete, null, tint = Red)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        Text("یادآوری و گزارش", color = Color.White, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("یادآوری ساعتی", color = Color.White, fontWeight = FontWeight.Bold)
                                        Text("اعلان برای بررسی دستی حساب‌ها", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = hourly, onCheckedChange = { v ->
                                        hourly = v; prefs.edit().putBoolean("hourly_enabled", v).apply()
                                        val wm = WorkManager.getInstance(context)
                                        if (v) {
                                            val req = PeriodicWorkRequestBuilder<HourlyWorker>(1, TimeUnit.HOURS).build()
                                            wm.enqueueUniquePeriodicWork("cod_hourly_reminder", ExistingPeriodicWorkPolicy.UPDATE, req)
                                        } else wm.cancelUniqueWork("cod_hourly_reminder")
                                    })
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("خلاصه وضعیت", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("حساب‌ها: ${accounts.size}", color = Muted)
                        Text("توکن‌های ثبت‌شده: ${accounts.sumOf { it.tokens }}", color = Muted)
                        Text("مأموریت‌های تکمیل‌شده: ${tasks.count { it.done }} از ${tasks.size}", color = Muted)
                        Text("آخرین داده‌ها فقط بر اساس اطلاعاتی است که خودت در برنامه ثبت کرده‌ای.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    4 -> {
                        Text("دستیار عملیات نیمه‌خودکار", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("برنامه فقط صفحات رسمی را باز می‌کند و مراحل را ثبت می‌کند؛ اطلاعات ورود و کپچا را خودت در سایت رسمی وارد کن.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("صفحات رسمی ثبت‌نام", color = Color.White, fontWeight = FontWeight.Bold)
                                Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://accounts.google.com/signup"))) }, colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.fillMaxWidth()) { Text("بازکردن ثبت‌نام Google") }
                                OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.callofduty.com/"))) }, modifier = Modifier.fillMaxWidth()) { Text("بازکردن وب‌سایت رسمی Call of Duty") }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("چک‌لیست ثبت‌نام — تیک‌ها روی دستگاه ذخیره می‌شوند", color = Color.White, fontWeight = FontWeight.Bold)
                        val steps = listOf(
                            "صفحه رسمی ثبت‌نام را باز کردم",
                            "اطلاعات لازم را خودم وارد کردم",
                            "کپچا را شخصاً تکمیل کردم",
                            "کد تأیید را در سایت رسمی وارد کردم",
                            "حساب Call of Duty را خودم ایجاد یا متصل کردم",
                            "نتیجه را در بخش حساب‌ها ثبت کردم"
                        )
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                            items(steps.size) { index ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = operationChecks.getOrElse(index) { false }, onCheckedChange = { checked ->
                                            val updated = operationChecks.toMutableList()
                                            while (updated.size < steps.size) updated.add(false)
                                            updated[index] = checked
                                            operationChecks = updated
                                            prefs.edit().putString("operation_checks", JSONArray(updated).toString()).apply()
                                        })
                                        Text(steps[index], color = Color.White, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        val clipboard = LocalClipboardManager.current
                        val filtered = Nicknames.filter { it.contains(nicknameQuery.trim(), ignoreCase = true) }
                        Text("بانک ۵۰۰ اسم مستعار", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("ترکیبی از سبک نظامی، سایبری و رقابتی", color = Muted, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(nicknameQuery, { nicknameQuery = it }, label = { Text("جست‌وجوی اسم") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { chosenNickname = Nicknames.random() }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("انتخاب تصادفی") }
                            Text("نتایج: ${filtered.size}", color = Muted)
                        }
                        if (chosenNickname.isNotBlank()) {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(chosenNickname, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { clipboard.setText(AnnotatedString(chosenNickname)) }) { Text("کپی", color = Red) }
                                }
                            }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(filtered) { nick ->
                                Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(nick, color = Color.White, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { chosenNickname = nick; clipboard.setText(AnnotatedString(nick)) }) { Text("انتخاب و کپی", color = Red) }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd) AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("افزودن حساب") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(alias, { alias = it }, label = { Text("نام نمایشی حساب") })
                    OutlinedTextField(region, { region = it }, label = { Text("منطقه / سرور") })
                    OutlinedTextField(tokens, { tokens = it.filter(Char::isDigit) }, label = { Text("تعداد توکن فعلی") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(note, { note = it }, label = { Text("یادداشت (بدون رمز عبور)") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (alias.isNotBlank()) {
                        accounts = accounts + GameAccount(System.currentTimeMillis(), alias.trim(), region.trim(), tokens.toIntOrNull() ?: 0, note.trim())
                        saveAll(); alias = ""; region = "Global"; tokens = "0"; note = ""; showAdd = false
                    }
                }) { Text("ذخیره", color = Red) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("انصراف") } }
        )
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(10.dp)) {
            Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        }
    }
}
@Composable fun EmptyHint(s: String) { Text(s, color = Muted, modifier = Modifier.padding(18.dp)) }

fun loadAccounts(p: android.content.SharedPreferences): List<GameAccount> = try {
    val a = JSONArray(p.getString("accounts", "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let { GameAccount(it.getLong("id"), it.getString("title"), it.optString("region","Global"), it.optInt("tokens"), it.optString("note")) } }
} catch (_: Exception) { emptyList() }

fun loadOperationChecks(p: android.content.SharedPreferences): List<Boolean> = try {
    val a = JSONArray(p.getString("operation_checks", "[]"))
    (0 until a.length()).map { a.optBoolean(it, false) }
} catch (_: Exception) { emptyList() }

fun loadTasks(p: android.content.SharedPreferences): List<TaskItem> = try {
    val a = JSONArray(p.getString("tasks", "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let { TaskItem(it.getLong("id"), it.getLong("accountId"), it.getString("title"), it.optBoolean("done")) } }
} catch (_: Exception) { emptyList() }
